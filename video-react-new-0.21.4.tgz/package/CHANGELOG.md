<a name="0.21.4"></a>
## 0.21.4 (2025-12-26)


### Bug Fixes

* rm docs pages ([4a7349d](https://github.com/thind9xdev/video-react-new/commit/4a7349d))
* rm docs pages [#2](https://github.com/thind9xdev/video-react-new/issues/2) ([38a455b](https://github.com/thind9xdev/video-react-new/commit/38a455b))
* update react 19 ([511554c](https://github.com/thind9xdev/video-react-new/commit/511554c))
* update readme ([0a4bcf4](https://github.com/thind9xdev/video-react-new/commit/0a4bcf4))
* update support react 19 ([a107d5a](https://github.com/thind9xdev/video-react-new/commit/a107d5a))



# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Fixed
- **Module Resolution:** Fixed a "Module not found" error when using the package with bundlers like Webpack. The `package.json` now points to the correct distribution files (`dist/` instead of `lib/`).
- **TypeScript Support:** Resolved an issue where `npm` would fail to find type definitions (`@types/video-react-new`). The package now correctly bundles and declares its own TypeScript types.
- **React 19 Compatibility:** Removed usage of the legacy `contextTypes` API in the `Player` component, fixing a critical error when using the library with React 19.
